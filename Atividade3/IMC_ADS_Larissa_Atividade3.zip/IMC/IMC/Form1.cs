﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            double Altura, Peso;
            if ((double.TryParse(txtAltura.Text, out Altura)) &&
            (double.TryParse(txtPeso.Text, out Peso)))

            {
                double IMC;
                IMC = Peso / (Math.Pow(Altura, 2));
                IMC = Math.Round(IMC, 1); //Para arrendondar
                txtIMC.Text = IMC.ToString("N1"); //Apresentar a mensagem

                if ((Peso > 0) && (Altura > 0))
                {
                    if (IMC < 18.5)
                        MessageBox.Show("Magreza");
                    else if ((IMC >= 18.5) && (IMC <= 24.9))
                        MessageBox.Show("Normal");
                    else if ((IMC >= 25) && (IMC <= 29.9))
                        MessageBox.Show("Sobrepeso");
                    else if ((IMC >= 30) && (IMC <= 40))
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade Grave!");
                }
                else
                    MessageBox.Show("Valores Incorretos!");
            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Text = String.Empty;

            txtPeso.Focus();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

