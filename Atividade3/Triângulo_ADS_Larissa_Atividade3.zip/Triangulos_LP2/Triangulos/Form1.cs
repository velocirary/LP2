﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double A, B, C;

            if(!double.TryParse(txtValA.Text, out A)||
               !double.TryParse(txtValB.Text, out B)||
               !double.TryParse(txtValC.Text, out C))
            {
                MessageBox.Show("Valores Devem ser Numericos");
            }
            else
            {
                if ((A > 0) && (B > 0) && (C > 0))
                        {
                    if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) &&
                        B > Math.Abs(A - C) && C < (A + B) && C > Math.Abs(A - B))
                    {
                        if (A == B && B == C)
                        {
                            MessageBox.Show("Triângulo Equilátero"); ;
                        }
                        else
                        {
                            if (A == B || A == C || C == B)
                            {
                                MessageBox.Show("Triangulo isósceles");
                            }
                            else
                            {
                                MessageBox.Show("Triangulo Escaleno");
                            }
                        }
                    }
                }
                else
                    MessageBox.Show("Os valores não formam um triangulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Clear();
            txtValC.Text = String.Empty;

            txtValA.Focus();

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
