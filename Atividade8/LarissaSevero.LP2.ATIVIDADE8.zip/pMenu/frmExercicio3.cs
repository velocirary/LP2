﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            string stringona = txtPalavra.Text;
            int i;
            bool aux = false;

            stringona = stringona.ToLower();

            char[] Dados = stringona.ToCharArray();
            char[] Dados2 = stringona.ToCharArray();

            Array.Reverse(Dados);

            Convert.ToString(Dados);

            if ((txtPalavra.Text == ""))
            {
                MessageBox.Show("A palavra está em branco! Verifique 😊");
            }

            else
            {

                for (i = 0; i < stringona.Length; i++)
                {
                    if (Dados[i] == Dados2[i])
                    {
                        aux = true;
                    }
                    else
                    {
                        aux = false;
                        break;
                    }
                }
                if (aux == false)

                    MessageBox.Show("✩" + stringona.ToString() + " não é palindromo ✩");

                else
                    MessageBox.Show("✩ " + stringona.ToString() + " é palindromo ✩");
            }
        }
    }
}
       