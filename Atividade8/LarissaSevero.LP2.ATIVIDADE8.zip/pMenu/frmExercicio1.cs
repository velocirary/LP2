﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int i = 0, QtdeBranco = 0;

            char[] Dados = rchtxtDados.Text.ToCharArray();

            if ((rchtxtDados.Text == ""))
            {
                MessageBox.Show("Frase em branco! Verifique 😊");
            }
            else
            {

                for (i = 0; i < rchtxtDados.Text.Length; i++)
                {
                    if (char.IsWhiteSpace(Dados[i]))
                    {
                        QtdeBranco++;

                    }

                }
                MessageBox.Show("✩ Existem " + QtdeBranco.ToString() + " espaços em branco nessa frase ✩");
            }
        }

        private void btnLetrasR_Click(object sender, EventArgs e)
        {
            int LetraR = 0;

            char[] Dados = rchtxtDados.Text.ToCharArray();

            if ((rchtxtDados.Text == ""))
            {
                MessageBox.Show("Frase em branco! Verifique 😊");
            }
            else
            {
                foreach (char R in Dados)
                {
                    if (R == 'r' || R == 'R')
                    {
                        LetraR++;
                    }

                }
                MessageBox.Show("✩ Existe(m) " + LetraR.ToString() + " letras 'R' nessa frase ✩");
            }
        }   

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int LetraRepetida = 0, i = 0;

            if ((rchtxtDados.Text == ""))
            {
                MessageBox.Show("Frase em branco! Verifique 😊");
            }
            else
            {
                for (i = 1; i < rchtxtDados.Text.Length; i++)

                {
                    if (rchtxtDados.Text[i] == rchtxtDados.Text[i - 1])
                    {
                        LetraRepetida++;
                    }

                }
                MessageBox.Show("✩ Existe(m) " + LetraRepetida.ToString() + " letras repetidas ✩");
            }
        }
    }
}
  
