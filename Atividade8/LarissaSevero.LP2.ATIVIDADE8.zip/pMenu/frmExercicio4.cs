﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int B = 0, C = 0, D = 0, Producao = 0, Matricula;
            double Gratificacao = 0, SalBruto = 0, Salario;

            if (double.TryParse(mskbxSalario.Text, out Salario) && (double.TryParse(mskbxGratificacao.Text, out Gratificacao) &&
               (int.TryParse(txtProdução.Text, out Producao) && (int.TryParse(txtMatricula.Text, out Matricula)))))
            {
                if (Producao >= 100)
                    B = 1;
                else
                    B = 0;

                if (Producao >= 120)
                    C = 1;
                else
                    C = 0;

                if (Producao >= 150)
                    D = 1;
                else
                    D = 0;

                SalBruto = Salario + (Salario * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao);

                if (SalBruto > 7000)
                {
                    if (Producao >= 150 && Gratificacao != 0)
                    {

                    }
                    else
                        SalBruto = 7000;
                }
                MessageBox.Show("O salário bruto do funcionário é: " + SalBruto);
            }
            else
            {
                MessageBox.Show("Verique os campos! Preencha corretamente", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
