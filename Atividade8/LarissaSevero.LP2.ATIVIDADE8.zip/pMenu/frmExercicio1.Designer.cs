﻿
namespace pMenu
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtDados = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnLetrasR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rchtxtDados
            // 
            this.rchtxtDados.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rchtxtDados.Location = new System.Drawing.Point(117, 110);
            this.rchtxtDados.Name = "rchtxtDados";
            this.rchtxtDados.Size = new System.Drawing.Size(312, 57);
            this.rchtxtDados.TabIndex = 0;
            this.rchtxtDados.Text = "";
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEspacoBranco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEspacoBranco.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEspacoBranco.Font = new System.Drawing.Font("Berlin Sans FB", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnEspacoBranco.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEspacoBranco.Location = new System.Drawing.Point(51, 204);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(143, 65);
            this.btnEspacoBranco.TabIndex = 1;
            this.btnEspacoBranco.Text = "Quantidade de Espaços em Branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = false;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnLetrasR
            // 
            this.btnLetrasR.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLetrasR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLetrasR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLetrasR.Font = new System.Drawing.Font("Berlin Sans FB", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLetrasR.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLetrasR.Location = new System.Drawing.Point(200, 204);
            this.btnLetrasR.Name = "btnLetrasR";
            this.btnLetrasR.Size = new System.Drawing.Size(143, 65);
            this.btnLetrasR.TabIndex = 2;
            this.btnLetrasR.Text = "Quantidade da letra \"R\"";
            this.btnLetrasR.UseVisualStyleBackColor = false;
            this.btnLetrasR.Click += new System.EventHandler(this.btnLetrasR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnParLetras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnParLetras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParLetras.Font = new System.Drawing.Font("Berlin Sans FB", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnParLetras.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnParLetras.Location = new System.Drawing.Point(349, 204);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(143, 65);
            this.btnParLetras.TabIndex = 2;
            this.btnParLetras.Text = "Quantidade de letras sequencias";
            this.btnParLetras.UseVisualStyleBackColor = false;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Berlin Sans FB", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTitulo.Location = new System.Drawing.Point(172, 69);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(209, 26);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "DIGITE UMA FRASE";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(500, 320);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnLetrasR);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.rchtxtDados);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmExercicio1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtDados;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnLetrasR;
        private System.Windows.Forms.Button btnParLetras;
        private System.Windows.Forms.Label lblTitulo;
    }
}