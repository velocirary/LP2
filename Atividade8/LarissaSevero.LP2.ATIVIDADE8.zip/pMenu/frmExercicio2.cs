﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double H = 0, N, i;

            if ((txtNumero.Text == ""))
            {
                MessageBox.Show("Número em branco! Verifique 😊");
            }
            else
            {
                if ((double.TryParse(txtNumero.Text, out N)))
                {
                    if (N > 0)
                    {
                        for (i = 1; i < N + 1; i++)
                        {
                            H += 1 / i;

                        }
                        MessageBox.Show("★ O Resultado do calculo é :  " + H.ToString() + " ★");
                    }
                    else
                        MessageBox.Show("⇏ O Número " + H.ToString() + " está incorreto ⇍");
                }
            }
        }
    }
}
